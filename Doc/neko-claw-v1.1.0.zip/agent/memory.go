package main

import (
	"encoding/json"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type Memory struct {
	ID        string    `json:"id"`
	Content   string    `json:"content"`
	Category  string    `json:"category"` // facts, preferences, events, commands
	Priority  int       `json:"priority"` // 1-5, higher = more important
	CreatedAt time.Time `json:"createdAt"`
	LastUsed  time.Time `json:"lastUsed"`
	Tags      []string  `json:"tags"`
}

type MemoryStore struct {
	Memories []Memory `json:"memories"`
	mu       sync.RWMutex
	filePath string
}

var memoryStore *MemoryStore

func initMemoryStore() error {
	dataDir := filepath.Join("data")
	if err := os.MkdirAll(dataDir, 0755); err != nil {
		return err
	}

	storePath := filepath.Join(dataDir, "memories.json")
	store := &MemoryStore{
		Memories: []Memory{},
		filePath: storePath,
	}

	// Load existing memories
	if data, err := os.ReadFile(storePath); err == nil {
		if err := json.Unmarshal(data, store); err != nil {
			log.Printf("Warning: Could not parse memories file: %v", err)
		}
	} else if !os.IsNotExist(err) {
		return err
	}

	memoryStore = store
	return nil
}

func (ms *MemoryStore) save() error {
	ms.mu.Lock()
	defer ms.mu.Unlock()

	data, err := json.MarshalIndent(ms, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(ms.filePath, data, 0644)
}

func (ms *MemoryStore) AddMemory(content, category string, priority int, tags []string) error {
	ms.mu.Lock()
	defer ms.mu.Unlock()

	if priority < 1 {
		priority = 1
	}
	if priority > 5 {
		priority = 5
	}

	memory := Memory{
		ID:        generateID(),
		Content:   content,
		Category:  category,
		Priority:  priority,
		CreatedAt: time.Now(),
		LastUsed:  time.Now(),
		Tags:      tags,
	}

	ms.Memories = append(ms.Memories, memory)
	return ms.saveInternal()
}

func (ms *MemoryStore) saveInternal() error {
	data, err := json.MarshalIndent(ms, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(ms.filePath, data, 0644)
}

func (ms *MemoryStore) GetMemories(category string, limit int) []Memory {
	ms.mu.RLock()
	defer ms.mu.RUnlock()

	filtered := make([]Memory, 0)
	for _, m := range ms.Memories {
		if category == "" || m.Category == category {
			filtered = append(filtered, m)
		}
	}

	// Sort by priority (highest first) and limit
	for i := 0; i < len(filtered); i++ {
		for j := i + 1; j < len(filtered); j++ {
			if filtered[j].Priority > filtered[i].Priority {
				filtered[i], filtered[j] = filtered[j], filtered[i]
			}
		}
	}

	if limit > 0 && len(filtered) > limit {
		filtered = filtered[:limit]
	}

	return filtered
}

func (ms *MemoryStore) SearchMemories(query string, limit int) []Memory {
	ms.mu.RLock()
	defer ms.mu.RUnlock()

	query = strings.ToLower(query)
	relevant := make([]Memory, 0)

	for _, m := range ms.Memories {
		contentMatch := strings.Contains(strings.ToLower(m.Content), query)
		tagMatch := false
		for _, tag := range m.Tags {
			if strings.Contains(strings.ToLower(tag), query) {
				tagMatch = true
				break
			}
		}

		if contentMatch || tagMatch {
			relevant = append(relevant, m)
		}
	}

	// Sort by priority
	for i := 0; i < len(relevant); i++ {
		for j := i + 1; j < len(relevant); j++ {
			if relevant[j].Priority > relevant[i].Priority {
				relevant[i], relevant[j] = relevant[j], relevant[i]
			}
		}
	}

	if limit > 0 && len(relevant) > limit {
		relevant = relevant[:limit]
	}

	return relevant
}

func (ms *MemoryStore) DeleteMemory(id string) error {
	ms.mu.Lock()
	defer ms.mu.Unlock()

	for i, m := range ms.Memories {
		if m.ID == id {
			ms.Memories = append(ms.Memories[:i], ms.Memories[i+1:]...)
			return ms.saveInternal()
		}
	}

	return nil
}

func (ms *MemoryStore) ClearMemories(category string) error {
	ms.mu.Lock()
	defer ms.mu.Unlock()

	if category == "" {
		ms.Memories = []Memory{}
	} else {
		var filtered []Memory
		for _, m := range ms.Memories {
			if m.Category != category {
				filtered = append(filtered, m)
			}
		}
		ms.Memories = filtered
	}

	return ms.saveInternal()
}

func (ms *MemoryStore) GetMemoryStats() map[string]interface{} {
	ms.mu.RLock()
	defer ms.mu.RUnlock()

	stats := map[string]interface{}{
		"total": len(ms.Memories),
	}

	categoryCount := make(map[string]int)
	for _, m := range ms.Memories {
		categoryCount[m.Category]++
	}
	stats["byCategory"] = categoryCount

	return stats
}
