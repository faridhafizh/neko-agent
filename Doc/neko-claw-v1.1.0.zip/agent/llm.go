package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os/exec"
	"regexp"
	"strings"
	"time"

	openai "github.com/sashabaranov/go-openai"
)

type ChatRequest struct {
	Message   string `json:"message"`
	SessionID string `json:"sessionId,omitempty"`
}

type ChatResponse struct {
	Reply          string          `json:"reply"`
	SessionID      string          `json:"sessionId"`
	HasPendingCmd  bool            `json:"hasPendingCmd"`
	PendingCommand *PendingCommand `json:"pendingCommand,omitempty"`
	ActiveSoul     string          `json:"activeSoul"`
	SoulEmoji      string          `json:"soulEmoji"`
	MemoryCount    int             `json:"memoryCount"`
}

var conversationHistory []openai.ChatCompletionMessage // Deprecated: use sessions now

// powershellTool is the OpenAI function tool definition for proposing PowerShell commands.
// Defined once at package level to avoid duplication between handleChat and handleApproveCommand.
var powershellTool = openai.Tool{
	Type: openai.ToolTypeFunction,
	Function: &openai.FunctionDefinition{
		Name:        "run_powershell_command",
		Description: "Propose a powershell command to execute on the user's computer. The user must approve it first.",
		Parameters: json.RawMessage(`{
			"type": "object",
			"properties": {
				"command": {
					"type": "string",
					"description": "The exact powershell command to run."
				},
				"description": {
					"type": "string",
					"description": "A short summary explaining what this command does safely."
				}
			},
			"required": ["command", "description"]
		}`),
	},
}

func getOpenAIClient() *openai.Client {
	settingsMutex.RLock()
	apiKey := currentSettings.ApiKey
	apiUrl := currentSettings.ApiUrl
	settingsMutex.RUnlock()

	config := openai.DefaultConfig(apiKey)
	if apiUrl != "" {
		if before, ok := strings.CutSuffix(apiUrl, "/chat/completions"); ok {
			apiUrl = before
		}
		config.BaseURL = apiUrl
	}
	return openai.NewClientWithConfig(config)
}

func handleChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req ChatRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Get or create session
	var session *ChatSession
	if req.SessionID != "" {
		session = chatHistoryStore.GetSession(req.SessionID)
	}
	if session == nil {
		session = chatHistoryStore.CreateSession("New Chat")
	}

	// Search for relevant memories based on user message
	relevantMemories := memoryStore.SearchMemories(req.Message, 5)

	// Build memory context string
	memoryContext := ""
	if len(relevantMemories) > 0 {
		memoryContext = "\n\nRelevant memories from past interactions:\n"
		for _, mem := range relevantMemories {
			memoryContext += fmt.Sprintf("- [%s] %s\n", mem.Category, mem.Content)
			// Update last used timestamp
			mem.LastUsed = time.Now()
		}
		// Save updated timestamps (best effort, non-blocking)
		go func() {
			memoryStore.mu.Lock()
			memoryStore.saveInternal()
			memoryStore.mu.Unlock()
		}()
	}

	// Build system prompt with soul and memory
	activeSoul := soulStore.GetActiveSoul()
	systemPrompt := activeSoul.SystemPrompt + memoryContext

	// Build conversation from session messages
	var messages []openai.ChatCompletionMessage
	messages = append(messages, openai.ChatCompletionMessage{
		Role:    openai.ChatMessageRoleSystem,
		Content: systemPrompt,
	})
	for _, msg := range session.Messages {
		messages = append(messages, openai.ChatCompletionMessage{
			Role:    msg.Role,
			Content: msg.Content,
		})
	}

	// Add current user message
	messages = append(messages, openai.ChatCompletionMessage{
		Role:    openai.ChatMessageRoleUser,
		Content: req.Message,
	})

	settingsMutex.RLock()
	model := currentSettings.Model
	apiKey := currentSettings.ApiKey
	settingsMutex.RUnlock()

	if apiKey == "" {
		http.Error(w, "API Key is missing. Silakan isi konfigurasi API Key terlebih dahulu di menu ⚙️ Settings.", http.StatusBadRequest)
		return
	}

	client := getOpenAIClient()
	ctx, cancel := context.WithTimeout(r.Context(), 90*time.Second)
	defer cancel()
	resp, err := client.CreateChatCompletion(
		ctx,
		openai.ChatCompletionRequest{
			Model:    model,
			Messages: messages,
			Tools:    []openai.Tool{powershellTool},
		},
	)

	if err != nil {
		log.Printf("Chat completion error: %v", err)

		// Check if it's a rate limit error
		if strings.Contains(err.Error(), "429") || strings.Contains(err.Error(), "Rate limit") {
			http.Error(w, "Rate limit reached. Please wait a moment before sending another message.", http.StatusTooManyRequests)
			return
		}

		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	choice := resp.Choices[0]

	// Save messages to session
	chatHistoryStore.AddMessage(session.ID, ChatMessage{Role: "user", Content: req.Message})
	chatHistoryStore.AddMessage(session.ID, ChatMessage{Role: "assistant", Content: choice.Message.Content})

	// Get memory stats
	memStats := memoryStore.GetMemoryStats()
	memoryCount := memStats["total"].(int)

	res := ChatResponse{
		Reply:       choice.Message.Content,
		SessionID:   session.ID,
		ActiveSoul:  activeSoul.Name,
		SoulEmoji:   activeSoul.Emoji,
		MemoryCount: memoryCount,
	}

	if len(choice.Message.ToolCalls) > 0 {
		// Process all tool calls, but we only expect one run_powershell_command per request
		for _, toolCall := range choice.Message.ToolCalls {
			if toolCall.Function.Name == "run_powershell_command" {
				var args map[string]string
				json.Unmarshal([]byte(toolCall.Function.Arguments), &args)

				cmdID := toolCall.ID
				pendingCmd := &PendingCommand{
					ID:          cmdID,
					SessionID:   session.ID,
					Command:     args["command"],
					Description: args["description"],
				}

				pendingCmdsMutex.Lock()
				pendingCommands[cmdID] = pendingCmd
				pendingCmdsMutex.Unlock()

				res.HasPendingCmd = true
				res.PendingCommand = pendingCmd
				if res.Reply == "" {
					res.Reply = fmt.Sprintf("I need to run a command: %s", args["description"])
				}
				// Break after processing the first tool call (UI handles one at a time)
				break
			}
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(res)
}

func handleApproveCommand(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		ID string `json:"id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	pendingCmdsMutex.RLock()
	cmd, exists := pendingCommands[req.ID]
	pendingCmdsMutex.RUnlock()

	if !exists {
		http.Error(w, "Command not found or already executed", http.StatusNotFound)
		return
	}

	// Remove from pending
	pendingCmdsMutex.Lock()
	delete(pendingCommands, req.ID)
	pendingCmdsMutex.Unlock()

	// Execute it
	execCmd := exec.Command("pwsh", "-Command", cmd.Command)
	output, err := execCmd.CombinedOutput()
	resultStr := string(output)

	// Clean ANSI escape codes (PowerShell colors)
	ansiRegex := regexp.MustCompile(`\x1b\[[0-9;]*m`)
	resultStr = ansiRegex.ReplaceAllString(resultStr, "")

	if err != nil {
		resultStr += fmt.Sprintf("\nError: %v", err)
	}

	// Save command execution result to session
	if cmd.SessionID != "" {
		chatHistoryStore.AddMessage(cmd.SessionID, ChatMessage{
			Role:    "system",
			Content: fmt.Sprintf("Command executed: %s\nOutput:\n%s", cmd.Command, resultStr),
		})
	}

	// Build messages from session for follow-up
	var messages []openai.ChatCompletionMessage
	if cmd.SessionID != "" {
		session := chatHistoryStore.GetSession(cmd.SessionID)
		if session != nil {
			activeSoul := soulStore.GetActiveSoul()
			messages = append(messages, openai.ChatCompletionMessage{
				Role:    openai.ChatMessageRoleSystem,
				Content: activeSoul.SystemPrompt,
			})
			for _, msg := range session.Messages {
				messages = append(messages, openai.ChatCompletionMessage{
					Role:    msg.Role,
					Content: msg.Content,
				})
			}
		}
	}

	if len(messages) == 0 {
		json.NewEncoder(w).Encode(map[string]string{
			"status": "success",
			"output": resultStr,
			"reply":  "Execution finished.",
		})
		return
	}

	// Prompt the AI again with the result
	client := getOpenAIClient()
	settingsMutex.RLock()
	model := currentSettings.Model
	settingsMutex.RUnlock()

	resp, chatErr := client.CreateChatCompletion(
		context.Background(),
		openai.ChatCompletionRequest{
			Model:    model,
			Messages: messages,
			Tools:    []openai.Tool{powershellTool},
		},
	)

	reply := "Execution finished. AI didn't respond."
	if chatErr != nil {
		reply = fmt.Sprintf("Execution finished, but AI encountered an error: %v", chatErr)
	} else if len(resp.Choices) > 0 {
		reply = resp.Choices[0].Message.Content
		if cmd.SessionID != "" {
			chatHistoryStore.AddMessage(cmd.SessionID, ChatMessage{
				Role:    "assistant",
				Content: reply,
			})
		}
	}

	json.NewEncoder(w).Encode(map[string]string{
		"status":    "success",
		"output":    resultStr,
		"reply":     reply,
		"sessionId": cmd.SessionID,
	})
}

func handleRejectCommand(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		ID string `json:"id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	pendingCmdsMutex.Lock()
	cmd, exists := pendingCommands[req.ID]
	delete(pendingCommands, req.ID)
	pendingCmdsMutex.Unlock()

	if exists && cmd.SessionID != "" {
		chatHistoryStore.AddMessage(cmd.SessionID, ChatMessage{
			Role:    "system",
			Content: "User rejected the execution of this command.",
		})
	}

	json.NewEncoder(w).Encode(map[string]string{
		"status":    "rejected",
		"sessionId": cmd.SessionID,
	})
}
