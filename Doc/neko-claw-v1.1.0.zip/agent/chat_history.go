package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"
)

type ChatMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type ChatSession struct {
	ID        string        `json:"id"`
	Title     string        `json:"title"`
	Messages  []ChatMessage `json:"messages"`
	CreatedAt time.Time     `json:"createdAt"`
	UpdatedAt time.Time     `json:"updatedAt"`
	Archived  bool          `json:"archived"`
}

// LastMessagePreview returns a truncated preview of the last non-system message.
func (s *ChatSession) LastMessagePreview() string {
	for i := len(s.Messages) - 1; i >= 0; i-- {
		m := s.Messages[i]
		if m.Role == "user" || m.Role == "assistant" {
			preview := m.Content
			if len(preview) > 60 {
				preview = preview[:60] + "…"
			}
			return preview
		}
	}
	return ""
}

type ChatHistoryStore struct {
	mu       sync.RWMutex
	Sessions []*ChatSession `json:"sessions"`
	filePath string
}

var chatHistoryStore *ChatHistoryStore

func initChatHistoryStore() error {
	storePath := filepath.Join("data", "chat_history.json")

	store := &ChatHistoryStore{
		Sessions: make([]*ChatSession, 0),
		filePath: storePath,
	}

	// Load existing data
	data, err := os.ReadFile(storePath)
	if err != nil {
		if os.IsNotExist(err) {
			log.Println("No chat history file found, creating new one")
		} else {
			return fmt.Errorf("failed to read chat history: %w", err)
		}
	} else {
		if err := json.Unmarshal(data, store); err != nil {
			return fmt.Errorf("failed to parse chat history: %w", err)
		}
	}

	chatHistoryStore = store
	return nil
}

func (s *ChatHistoryStore) save() error {
	data, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(s.filePath, data, 0644)
}

func (s *ChatHistoryStore) CreateSession(title string) *ChatSession {
	s.mu.Lock()
	defer s.mu.Unlock()

	session := &ChatSession{
		ID:        generateID(),
		Title:     title,
		Messages:  make([]ChatMessage, 0),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
		Archived:  false,
	}

	s.Sessions = append(s.Sessions, session)
	s.save()
	return session
}

func (s *ChatHistoryStore) GetSession(id string) *ChatSession {
	s.mu.RLock()
	defer s.mu.RUnlock()

	for _, session := range s.Sessions {
		if session.ID == id {
			return session
		}
	}
	return nil
}

func (s *ChatHistoryStore) GetActiveSession() *ChatSession {
	s.mu.RLock()
	defer s.mu.RUnlock()

	// Return the most recent non-archived session
	for i := len(s.Sessions) - 1; i >= 0; i-- {
		if !s.Sessions[i].Archived {
			return s.Sessions[i]
		}
	}
	return nil
}

func (s *ChatHistoryStore) AddMessage(sessionID string, message ChatMessage) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	for _, session := range s.Sessions {
		if session.ID == sessionID {
			session.Messages = append(session.Messages, message)
			session.UpdatedAt = time.Now()

			// Auto-update title from first user message
			if session.Title == "New Chat" && message.Role == "user" {
				// Use first 50 chars of message as title
				title := message.Content
				if len(title) > 50 {
					title = title[:50] + "..."
				}
				session.Title = title
			}

			return s.save()
		}
	}
	return fmt.Errorf("session not found: %s", sessionID)
}

func (s *ChatHistoryStore) UpdateSessionTitle(id string, title string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	for _, session := range s.Sessions {
		if session.ID == id {
			session.Title = title
			session.UpdatedAt = time.Now()
			return s.save()
		}
	}
	return fmt.Errorf("session not found: %s", id)
}

func (s *ChatHistoryStore) ArchiveSession(id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	for _, session := range s.Sessions {
		if session.ID == id {
			session.Archived = true
			session.UpdatedAt = time.Now()
			return s.save()
		}
	}
	return fmt.Errorf("session not found: %s", id)
}

func (s *ChatHistoryStore) UnarchiveSession(id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	for _, session := range s.Sessions {
		if session.ID == id {
			session.Archived = false
			session.UpdatedAt = time.Now()
			return s.save()
		}
	}
	return fmt.Errorf("session not found: %s", id)
}

func (s *ChatHistoryStore) DeleteSession(id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	for i, session := range s.Sessions {
		if session.ID == id {
			s.Sessions = append(s.Sessions[:i], s.Sessions[i+1:]...)
			return s.save()
		}
	}
	return fmt.Errorf("session not found: %s", id)
}

func (s *ChatHistoryStore) GetSessions(includeArchived bool) []*ChatSession {
	s.mu.RLock()
	defer s.mu.RUnlock()

	result := make([]*ChatSession, 0)
	for _, session := range s.Sessions {
		if includeArchived || !session.Archived {
			result = append(result, session)
		}
	}

	// Sort by UpdatedAt descending (newest first) — O(n log n)
	sort.Slice(result, func(i, j int) bool {
		return result[i].UpdatedAt.After(result[j].UpdatedAt)
	})

	return result
}
